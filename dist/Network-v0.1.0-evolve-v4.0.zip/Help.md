| **Name** | **cwLayoutNetworkt** | **Version** | 1.0 |
| --- | --- | --- | --- |
| **Updated by** | Mathias PFAUWADEL |

## Description 
Allow you to display objects and their associations in a network
## Screen Shot
The layout will scan all of your hierarchy tree, and put it in a network.
You can use filter to choose which item to display

![](https://github.com/nevakee716/cwNetwork/raw/master/screen/1.jpg)

### Node setup
![](https://github.com/nevakee716/cwNetwork/raw/master/screen/2.jpg)
